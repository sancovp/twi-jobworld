---
name: terminal-funnel
description: When building gamified terminal-based application funnels for communities. Creates fake CLI interfaces with easter egg hunts that capture leads, test domain knowledge, and generate social proof. Use when user wants a "Claude Community style" signup, terminal-based lead capture, or gamified waitlist.
---

# Terminal Funnel Builder

## What You're Building

A simulated terminal that:
1. Captures lead info (email first, then explore)
2. Hides 16 easter eggs triggered by CLI commands
3. Creates artificial scarcity ("at capacity")
4. Generates screenshot-worthy victory screens

## Core Flow

```
Welcome → Form (email capture) → "Thank you + explore hint" → 
Easter egg hunt → Unlock threshold (6) → "Qualified but waitlisted" →
Continue hunting → Elite (16/16) → Victory screen + share CTA
```

## The 16 Standard Achievements

| Command | Achievement | Tests |
|---------|-------------|-------|
| `help` | Helper | RTFM |
| `ls` | Explorer | Navigation |
| `ls -la` | Hidden Seeker | Dotfiles |
| `cat [file]` | File Reader | File ops |
| `cat .[hidden]` | Secret Hunter | Config digging |
| `cd [dir]` | Navigator | Directory traversal |
| `sudo` | Super User | Privilege awareness |
| `Ctrl+C` | Interruptor | Process control |
| `clear` | Clean Slate | Terminal hygiene |
| `history` | Time Traveler | Shell history |
| `whoami` | Self Aware | Identity |
| `pwd` | Path Finder | Location |
| `vim`/`nano` | Editor Wars | Editor knowledge |
| `grep` | Pattern Matcher | Search |
| `man` | Manual Reader | Docs |
| `[custom]` | [Product] Whisperer | Product knowledge |

Adapt names/descriptions to domain (meditation, business, dev, etc.)

## File System Structure

```
/home/user/
├── [community]/
│   ├── README.md          # Welcome + hints
│   ├── [script].sh        # Runnable easter egg
│   ├── requirements.txt   # Domain requirements
│   ├── .[config]rc        # Hidden config with SECRET_COMMAND hint
│   └── .secrets/
│       └── [key].txt      # Deep discovery
├── .bashrc                # Alias hints (non-functional)
└── .profile               # Red herring (unreadable)
```

## Key Patterns

**Velvet Rope**: Even at 100%, "at capacity" - nobody gets instant access. It's a pre-launch email capture.

**Social Proof Generation**: Victory screen + explicit screenshot CTA + hashtag + handle = free distribution.

**Self-Selection**: Only target audience completes. The puzzle IS the qualification.

**Hint Layering**: Obvious → Subtle → Hidden. `help` tells you basics. `.bashrc` hints at secrets. `.secrets/.do-not-open` rewards reverse psychology.

## Implementation Checklist

- [ ] ASCII art header (figlet block style)
- [ ] Form capture BEFORE exploration
- [ ] 16 achievement triggers
- [ ] State persistence (localStorage)
- [ ] Status bar updates (Skill Level: N)
- [ ] Progress messaging at thresholds
- [ ] `[custom] --unlock` progress check
- [ ] `[custom] join --force` qualification screen
- [ ] Victory screen with all achievements listed
- [ ] Screenshot CTA with hashtag

## Domain Adaptation

**Dev community**: Standard CLI commands
**Meditation/spiritual**: `look`, `breathe`, `sit`, `whoami` → "Self Inquirer"
**Business**: `analyze`, `pivot`, `growth` → marketing terms

See `references/complete-guide.md` for full implementation details, code templates, and examples (SANCTUM, PAIAB, Claude Community).

## Exit Condition

Complete when:
- Single HTML file works end-to-end
- All 16 achievements trigger correctly
- Form submits to backend
- Victory screen renders cleanly for screenshots
