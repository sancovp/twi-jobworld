# Achievements Reference

## Standard 16 (Developer)

| Command | Achievement | Tests |
|---------|-------------|-------|
| `help` | Helper | RTFM |
| `ls` | Explorer | Navigation |
| `ls -la` | Hidden Seeker | Dotfiles |
| `cat [file]` | File Reader | Reading |
| `cat .[hidden]` | Secret Hunter | Configs |
| `cd [dir]` | Navigator | Traversal |
| `sudo` | Super User | Privileges |
| `Ctrl+C` | Interruptor | Escape |
| `clear` | Clean Slate | Screen mgmt |
| `history` | Time Traveler | History |
| `whoami` | Self Aware | Identity |
| `pwd` | Path Finder | Location |
| `vim/nano` | Editor Wars | Editors |
| `grep` | Pattern Matcher | Search |
| `man` | Manual Reader | Docs |
| `[custom]` | Whisperer | Product |

## Domain Adaptations

### Meditation
- Beginner's Mind, Observer, Shadow Seeker
- Sutra Reader, Esoteric Scholar, Path Walker
- Ego Transcender, Thought Interruptor, Mind Clearer
- Past Life Explorer, Self Inquirer, Present Moment
- Practice Explorer, Pattern Recognizer, Dharma Seeker, Awakened One

### Business
- Student, Market Scanner, Competitive Analyst
- Case Study Reader, Insider Intel, Pivot Master
- Shortcut Seeker, Campaign Killer, Slate Cleaner
- Data Historian, Brand Identity, Funnel Finder
- Tool Wars, Trend Spotter, Framework Finder, Growth Hacker

## Achievement Function
```javascript
function unlock(name) {
  if (!state.achievements[name]) {
    state.achievements[name] = true;
    showNotification(name);
    updateSkillLevel();
  }
}
```
