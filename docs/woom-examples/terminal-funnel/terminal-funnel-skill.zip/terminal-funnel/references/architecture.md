# Architecture Reference

## Visual Design System

### Color Palette
```css
--bg-primary: #1a1b26;
--bg-secondary: #24283b;
--text-primary: #a9b1d6;
--text-muted: #565f89;
--accent-green: #9ece6a;
--accent-yellow: #e0af68;
--accent-red: #f7768e;
--accent-cyan: #7dcfff;
--accent-magenta: #bb9af7;
```

## Funnel Phases

### Phase 1: Welcome
- ASCII art header
- Value proposition
- Two paths: "start" or explore

### Phase 2: Form
- One question at a time
- Micro-acknowledgments
- Fields: name, email, company, title, reason

### Phase 3: Processing
```
[████████████████████████████████████████] 100%
```

### Phase 4: Thank You + Hook
- Confirms submission
- Plants exploration seed
- Specific command hints

### Phase 5: Easter Egg Hunt
- Free exploration
- 16 achievements
- Progress tracking

### Phase 6: Qualification (6+ eggs)
- "You qualified!"
- "At capacity" scarcity
- Waitlist priority shown

### Phase 7: Victory (16/16)
- ELITE ASCII art
- All achievements listed
- Screenshot + share CTA

## State Object
```javascript
const state = {
  user: { name, email, company, title, reason },
  achievements: { /* 16 booleans */ },
  currentPath: '/home/user',
  commandHistory: [],
  phase: 'welcome'
};
```

## Milestones
- 6 eggs: Unlock threshold
- 10 eggs: HIGH priority
- 14 eggs: VERY HIGH
- 16 eggs: ELITE
