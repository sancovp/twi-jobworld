# Business Reference

## Conversion Benchmarks

| Metric | Target |
|--------|--------|
| Visit → Start | 50-70% |
| Start → Complete | 75-85% |
| Explore Rate | 40-60% |
| Qualification (6+ eggs) | 25-40% |
| Elite (16/16) | 7-15% |
| Screenshot Share | 20-35% |

## Lead Scoring
```javascript
function score(user) {
  let s = 0;
  s += user.eggsFound * 2.5;           // 0-40
  s += Math.min(20, user.minutes * 2); // 0-20
  s += user.reason.length > 50 ? 10 : 0;
  s += user.reason.length > 100 ? 5 : 0;
  return Math.min(100, s);
}
```

## Email Sequence

### Day 0: Confirmation
- "You found [X] eggs"
- "Higher scores = higher priority"

### Day 3: Re-engagement
- "Did you find .secrets?"
- Link back to terminal

### Day 7: Value
- Free resource for waitlist
- Build goodwill

### Trigger: Spot Opens
- "Your spot is ready"
- 48hr expiration
- Claim CTA

## Analytics Events
- Terminal Loaded
- Application Started/Completed
- Achievement Unlocked (name, count)
- Threshold Reached
- Elite Achieved (time_to_complete)
- Screenshot CTA Shown

## A/B Test Ideas
1. Hint verbosity (minimal vs explicit)
2. Unlock threshold (4 vs 6 vs 8)
3. Form length (3 vs 6 fields)
4. Scarcity copy variations

## Psychology Notes
- Sunk cost drives completion
- Velvet rope implies value
- Self-selection filters audience
- Screenshots = free distribution
