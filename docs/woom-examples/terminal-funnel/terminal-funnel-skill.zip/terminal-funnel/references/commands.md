# Commands Reference

## Parser Structure
```javascript
function parseCommand(input) {
  const [cmd, ...args] = input.trim().toLowerCase().split(/\s+/);
  
  switch(cmd) {
    case 'help': return cmdHelp();
    case 'ls': return cmdLs(args);
    case 'cd': return cmdCd(args[0]);
    case 'cat': return cmdCat(args[0]);
    case 'pwd': return state.currentPath;
    case 'whoami': return cmdWhoami();
    case 'clear': return clearTerminal();
    case 'history': return cmdHistory();
    case 'sudo': return cmdSudo();
    case 'vim': case 'nano': return cmdEditor();
    case 'grep': return cmdGrep();
    case 'man': return cmdMan();
    case '[custom]': return cmdCustom(args);
    default: return cmdNotFound(cmd);
  }
}
```

## Response Templates

### help
```
Available Commands:
  help, start, clear, ls, cat <file>

Tip: Power users know there are more commands...
```

### ls -la
```
  README.md
  apply.sh
  .config
  .secrets/

Hint: Hidden files often contain secrets...
```

### sudo
```
[sudo] password: ********

🔐 ELEVATED ACCESS ATTEMPT DETECTED

Nice try! Real developers don't need sudo...
```

### vim/nano
```
Opening vim...
  ~
  ~  Welcome to VIM - the editor that traps souls
  ~  Just kidding! Press any key to escape.

Achievement unlocked: Editor Wars!
```

### exit
```
Goodbye!

Just kidding, you can't exit. This is your destiny now.
```

## Keyboard Events
```javascript
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key === 'c') {
    unlock('interruptor');
  }
  if (e.key === 'ArrowUp') navigateHistory(-1);
  if (e.key === 'ArrowDown') navigateHistory(1);
});
```

## File System
```javascript
const files = {
  'README.md': '# Community\n\nHint: Not everything is visible...',
  '.config': 'SECRET_CMD="[custom] --unlock"',
  '.bashrc': 'alias power="echo Power users check dotfiles"'
};
```
