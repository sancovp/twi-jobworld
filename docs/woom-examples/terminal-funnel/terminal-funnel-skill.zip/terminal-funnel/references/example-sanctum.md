# SANCTUM Example (Meditation Community)

## Welcome ASCII
```
   ██████╗ █████╗ ███╗   ██╗ ██████╗████████╗██╗   ██╗███╗   ███╗
  ██╔════╝██╔══██╗████╗  ██║██╔════╝╚══██╔══╝██║   ██║████╗ ████║
  ███████╗███████║██╔██╗ ██║██║        ██║   ██║   ██║██╔████╔██║
  ╚════██║██╔══██║██║╚██╗██║██║        ██║   ██║   ██║██║╚██╔╝██║
  ███████║██║  ██║██║ ╚████║╚██████╗   ██║   ╚██████╔╝██║ ╚═╝ ██║
  ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝

A refuge for those who walk the contemplative path.

Type "enter" to begin... Or explore like a true seeker would. 🪷
```

## File System
- /home/seeker/refuge/welcome.txt
- /home/seeker/refuge/practice.sh
- /home/seeker/refuge/vows.txt
- /home/seeker/.dharma (hidden teachings)
- /home/seeker/refuge/.inner-sanctum/.emptiness

## Command Aliases
```javascript
const aliases = {
  'look': 'ls', 'observe': 'ls',
  'read': 'cat', 'study': 'cat',
  'enter': 'cd', 'walk': 'cd',
  'empty': 'clear', 'void': 'clear',
  'karma': 'history', 'who am i': 'whoami',
  'sit': 'meditate', 'breathe': 'meditate',
  'awaken': 'sanctum'
};
```

## Key File Contents

### .dharma
```
You found the dharma file.
Most seekers miss what is hidden in plain sight.

SEEKER_MODE=awakening
PRACTICE_HINT="Try 'sanctum --enter' when ready"
```

### .emptiness
```
             .


You found emptiness. It was here all along.
```

## Sudo Response
```
🙏 BYPASS ATTEMPT DETECTED

The ego wishes to skip the practice.
But there are no shortcuts to awakening.
Only the one who walks arrives.
```

## Victory Copy
- "The lamp has been passed"
- "The sangha awaits"
- "May all beings benefit from your practice"
